// Screens 1-3: Command Center, Agent Monitoring, Memory Graph
const { useState, useEffect, useRef, useMemo } = React;

/* =========================================================
   SCREEN 1 — AI COMMAND CENTER
   ========================================================= */
function CommandCenter() {
  const [streaming, setStreaming] = useState(true);
  const tps = useTicker(78, { min: 60, max: 120, step: 4, period: 800 });
  const ctxFill = useTicker(63, { min: 50, max: 78, step: 1, period: 1100 });
  const reply = useTyper(
    "Booted morning routine. Pulled 14 unread Telegram threads, flagged 3 from `@halim` containing decisions. Memory graph expanded with 7 new entities. Cost run-rate is on track at $1.84 / hr — projected daily within budget. Standing by for next directive.",
    { speed: 14 }
  );
  const heroSpark = useMemo(() => genWalk(60, 0.4, 6), []);
  const intents = [
    { k: "Summarize today's @work signal", t: "haiku · 220ms" },
    { k: "Plan a 3-block deep-work afternoon", t: "sonnet · 380ms" },
    { k: "Draft a kind decline to the Friday call", t: "haiku · 180ms" },
    { k: "Audit yesterday's spend per agent", t: "sonnet · 290ms" },
  ];
  const recents = [
    { who: "scout", what: "Indexed 142 messages from 6 chats", t: "12s ago", tone: "cyan" },
    { who: "scribe", what: "Wrote daily memo · 420 tokens", t: "1m ago", tone: "azure" },
    { who: "ledger", what: "Reconciled spend ledger · $0.18", t: "4m ago", tone: "pos" },
    { who: "concierge", what: "Replied on Telegram · @halim", t: "9m ago", tone: "cyan" },
  ];

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="00 · COMMAND"
        title={<>Good morning, <span className="font-serif italic text-white/85">Halim</span>. The system is listening.</>}
        sub="A composable surface for your AI workforce. Every signal in your life — Telegram, calendar, memory, code — converges here."
        right={
          <div className="flex items-center gap-2">
            <Pill tone="pos"><LiveDot/> ALL SYSTEMS NOMINAL</Pill>
            <Pill tone="cyan">v 4.2.0</Pill>
          </div>
        }
      />

      {/* HERO */}
      <Stagger delay={80}>
        <div className="grid grid-cols-12 gap-5">
          {/* Conductor */}
          <div className="col-span-12 lg:col-span-8 glass ring-aurora p-7 underglow-cyan relative overflow-hidden">
            <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(600px 240px at 20% 0%, rgba(91,212,255,0.10), transparent 60%)" }}/>
            <div className="flex items-start justify-between relative">
              <div>
                <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-cyan-glow/80 flex items-center gap-2"><LiveDot tone="cyan"/> conductor · live stream</div>
                <h2 className="text-[28px] tracking-[-0.02em] mt-2 font-medium leading-tight">A unified prompt for the entire <span className="font-serif italic text-cyan-glow">operating layer</span>.</h2>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 text-[11px] font-mono text-white/55">
                  <span>tok/s</span>
                  <span className="text-cyan-glow tabular text-[15px]">{tps.toFixed(0)}</span>
                </div>
                <Waveform />
              </div>
            </div>

            {/* Prompt */}
            <div className="mt-6 glass-strong rounded-[14px] p-4 border-white/[0.08] flex items-start gap-3 ring-aurora">
              <div className="w-9 h-9 rounded-[10px] grid place-items-center text-[#06080D] bg-cyan-glow shrink-0" style={{ boxShadow: "0 0 24px -4px #5BD4FF" }}><Icon.Spark/></div>
              <div className="flex-1">
                <div className="font-mono text-[10.5px] tracking-[0.16em] uppercase text-white/40 mb-1.5">prompt · sonnet-4.5 · routed via concierge</div>
                <div className="text-[14.5px] text-white/85">Run my daily kickoff: triage Telegram, summarize sleep, pick one deep-work block, and prepare a 5-bullet memo I can read in two minutes.</div>
                <div className="mt-3 flex items-center gap-2">
                  <Pill tone="cyan">/daily-kickoff</Pill>
                  <Pill>memory: morning</Pill>
                  <Pill>chains: 4</Pill>
                  <Pill>budget: $0.40</Pill>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button className="h-8 w-8 grid place-items-center rounded-md hover:bg-white/[0.06]"><Icon.Pause/></button>
                <Btn tone="primary" icon={<Icon.Send/>}>Dispatch</Btn>
              </div>
            </div>

            {/* Stream output */}
            <div className="mt-5 flex gap-3">
              <div className="w-1 rounded-full" style={{ background: "linear-gradient(#5BD4FF, transparent)" }}/>
              <div className="flex-1">
                <div className="font-mono text-[10.5px] tracking-[0.16em] uppercase text-white/40 mb-2 flex items-center gap-2">
                  <span>response · streaming</span>
                  <Pill tone="cyan">{streaming ? "ACTIVE" : "PAUSED"}</Pill>
                </div>
                <div className="text-[14.5px] leading-[1.65] text-white/82 max-w-3xl">
                  {reply}<span className="caret"/>
                </div>
              </div>
            </div>

            {/* Intents */}
            <div className="mt-7 grid grid-cols-2 gap-2">
              {intents.map((i, k) => (
                <Magnet key={k}>
                  <div className="group flex items-center justify-between glass-strong rounded-[12px] px-3.5 py-3 border border-white/[0.08] hover:border-cyan-glow/40 cursor-pointer transition">
                    <div className="flex items-center gap-3">
                      <div className="w-1.5 h-1.5 rounded-full bg-cyan-glow" style={{ boxShadow: "0 0 8px #5BD4FF" }}/>
                      <div className="text-[13px] text-white/85">{i.k}</div>
                    </div>
                    <div className="font-mono text-[10px] text-white/45 group-hover:text-cyan-glow transition">{i.t}</div>
                  </div>
                </Magnet>
              ))}
            </div>
          </div>

          {/* Side rail */}
          <div className="col-span-12 lg:col-span-4 space-y-5">
            <div className="glass p-5 ring-aurora">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/40">today · routed</div>
                  <div className="text-[34px] tracking-[-0.02em] font-medium mt-1">
                    <AnimatedNumber value={tps * 142} format={(v) => fmt.short(v)}/>
                    <span className="text-[16px] text-white/40 ml-1">tokens</span>
                  </div>
                </div>
                <Donut value={ctxFill} size={72} stroke={6} color="#5BD4FF" label={<div className="font-mono text-[12px] tabular">{ctxFill.toFixed(0)}<span className="text-[10px] text-white/45">%</span></div>}/>
              </div>
              <AreaChart data={heroSpark} h={88} />
              <div className="grid grid-cols-3 gap-3 mt-3 font-mono text-[11px]">
                <div><div className="text-white/45">p50</div><div className="text-cyan-glow tabular">218ms</div></div>
                <div><div className="text-white/45">p99</div><div className="text-white tabular">1.42s</div></div>
                <div><div className="text-white/45">cost</div><div className="text-white tabular">$2.14</div></div>
              </div>
            </div>

            <div className="glass p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/40">activity · agents</div>
                <Pill tone="cyan"><LiveDot tone="cyan"/> LIVE</Pill>
              </div>
              <div className="space-y-2.5">
                {recents.map((r, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <LiveDot tone={r.tone}/>
                    <div className="flex-1 min-w-0">
                      <div className="text-[13px] text-white/85"><span className="font-mono text-cyan-glow/90">{r.who}</span> <span className="text-white/55">· {r.what}</span></div>
                    </div>
                    <div className="font-mono text-[10.5px] text-white/40">{r.t}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom — agent grid + signal feed */}
        <div className="grid grid-cols-12 gap-5">
          <Card className="col-span-12 lg:col-span-7" eyebrow="ARRAY" title="Agent fleet · 12 active" right={<div className="flex gap-2"><Pill tone="pos">12 healthy</Pill><Pill>2 idle</Pill></div>}>
            <div className="grid grid-cols-3 gap-3">
              {[
                { name: "concierge", role: "router", tone: "cyan", load: 64 },
                { name: "scout", role: "indexer", tone: "azure", load: 48 },
                { name: "scribe", role: "writer", tone: "cyan", load: 22 },
                { name: "ledger", role: "finance", tone: "pos", load: 14 },
                { name: "atlas", role: "memory", tone: "azure", load: 71 },
                { name: "shipwright", role: "deploy", tone: "warn", load: 89 },
              ].map((a, i) => (
                <div key={i} className="glass-strong p-3 rounded-[12px]">
                  <div className="flex items-center justify-between">
                    <div className="text-[13px]">{a.name}</div>
                    <LiveDot tone={a.tone}/>
                  </div>
                  <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/45 mt-0.5">{a.role}</div>
                  <div className="mt-3 h-1 rounded-full bg-white/[0.05] overflow-hidden">
                    <div className="h-full" style={{
                      width: `${a.load}%`,
                      background: a.tone === "warn" ? "linear-gradient(90deg, #FFC56B33, #FFC56B)" :
                                  a.tone === "azure" ? "linear-gradient(90deg, #5C7BFF33, #5C7BFF)" :
                                  a.tone === "pos" ? "linear-gradient(90deg, #5EE7A833, #5EE7A8)" :
                                  "linear-gradient(90deg, #5BD4FF33, #5BD4FF)"
                    }}/>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="col-span-12 lg:col-span-5" eyebrow="SIGNAL" title="Inbound feed" right={<Pill tone="cyan"><LiveDot tone="cyan"/> 14/min</Pill>}>
            <div className="space-y-3 max-h-[260px] overflow-hidden relative">
              {[
                ["telegram", "@nora · 'we slipped a day, not blocking'", "cyan"],
                ["calendar", "Free 14:00–17:00 — held by atlas", "azure"],
                ["github", "`ai/concierge#412` failing on memory.cap", "danger"],
                ["telegram", "@halim · 'pls book Tue dinner'", "cyan"],
                ["sentry", "Spike on /api/run · p99 1.8s → 2.4s", "warn"],
                ["finance", "Anthropic invoice posted · $42.18", "pos"],
              ].map((s, i) => (
                <div key={i} className="flex items-center gap-3 py-1.5 border-b border-white/[0.04] last:border-0">
                  <div className="font-mono text-[10px] uppercase tracking-[0.14em] text-white/45 w-20">{s[0]}</div>
                  <div className="flex-1 text-[13px] text-white/82 truncate">{s[1]}</div>
                  <LiveDot tone={s[2]}/>
                </div>
              ))}
              <div className="absolute bottom-0 left-0 right-0 h-12 pointer-events-none" style={{ background: "linear-gradient(transparent, #0A0D14)" }}/>
            </div>
          </Card>
        </div>
      </Stagger>
    </div>
  );
}

/* =========================================================
   SCREEN 2 — AGENT MONITORING
   ========================================================= */
function AgentMonitoring() {
  const agents = [
    { name: "concierge",  role: "router · sonnet-4.5",     load: 64, tone: "cyan",  rps: 14.2, p99: 412, cost: 0.84, status: "thinking", thought: "routing /summarize → scribe via memory.work" },
    { name: "scout",      role: "indexer · haiku-4.5",     load: 48, tone: "azure", rps: 22.1, p99: 180, cost: 0.21, status: "working", thought: "embedding 142 chunks · batch 7/9" },
    { name: "scribe",     role: "writer · sonnet-4.5",     load: 22, tone: "cyan",  rps: 6.1,  p99: 720, cost: 1.24, status: "idle", thought: "—" },
    { name: "ledger",     role: "finance · haiku",         load: 14, tone: "pos",   rps: 1.2,  p99: 90,  cost: 0.04, status: "idle", thought: "—" },
    { name: "atlas",      role: "memory · sonnet",         load: 71, tone: "azure", rps: 8.9,  p99: 612, cost: 0.92, status: "thinking", thought: "merging 'q3-planning' subgraph (47 → 39 nodes)" },
    { name: "shipwright", role: "devops · haiku",          load: 89, tone: "warn",  rps: 0.4,  p99: 2210,cost: 0.02, status: "deploying", thought: "spinning workers (4/8) on hetzner-fsn" },
    { name: "wren",       role: "telegram · haiku",        load: 33, tone: "cyan",  rps: 4.8,  p99: 240, cost: 0.18, status: "working", thought: "drafting reply to @halim · 84 tokens" },
    { name: "north",      role: "scheduler · haiku",       load: 12, tone: "pos",   rps: 0.9,  p99: 110, cost: 0.03, status: "watching", thought: "watching 6 chats · cron in 4m12s" },
  ];
  const [sel, setSel] = useState(0);
  const a = agents[sel];
  const trace = [
    { t: "+0.000s", k: "intent",  v: "user.message · '/daily-kickoff'" },
    { t: "+0.012s", k: "route",   v: "→ concierge.router (sonnet-4.5)" },
    { t: "+0.041s", k: "memory",  v: "load(memory.work) · 12 entities" },
    { t: "+0.118s", k: "tool",    v: "telegram.read({since: 8h}) · 142 msgs" },
    { t: "+0.421s", k: "spawn",   v: "→ scout.embed_batch · 142 chunks" },
    { t: "+0.880s", k: "spawn",   v: "→ scribe.compose · brief.daily" },
    { t: "+1.412s", k: "stream",  v: "first token · 312ms ttf" },
  ];
  const cpu = useTicker(54, { step: 3, period: 700 });
  const mem = useTicker(67, { step: 2, period: 900 });
  const traffic = useMemo(() => genWalk(60, 0.5, 8), []);

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="01 · ORCHESTRATION"
        title="Agent monitoring"
        sub="Eight specialists. One nervous system. Every thought, tool call, and token billed in real time."
        right={
          <div className="flex items-center gap-2">
            <Pill tone="pos"><LiveDot/> 8/8 ONLINE</Pill>
            <Btn icon={<Icon.Plus/>}>Spawn agent</Btn>
          </div>
        }
      />

      <div className="grid grid-cols-12 gap-5">
        {/* Agent list */}
        <Card className="col-span-12 lg:col-span-4" eyebrow="FLEET" title="Specialists">
          <div className="space-y-1.5">
            {agents.map((g, i) => (
              <button key={i} onClick={() => setSel(i)}
                className={`w-full text-left rounded-[12px] px-3 py-2.5 flex items-center gap-3 border transition reveal ${i === sel ? 'bg-white/[0.06] border-cyan-glow/40 shadow-glow-cyan' : 'border-white/[0.05] hover:bg-white/[0.04]'}`}
                style={{ animationDelay: `${i * 50}ms` }}>
                <div className="relative">
                  <div className="w-9 h-9 rounded-[10px] glass-strong grid place-items-center" style={{ boxShadow: i === sel ? `0 0 18px -4px ${g.tone === 'cyan' ? '#5BD4FF' : g.tone === 'azure' ? '#5C7BFF' : g.tone === 'warn' ? '#FFC56B' : '#5EE7A8'}` : 'none' }}><Icon.Bot/></div>
                  <span className="absolute -bottom-0.5 -right-0.5"><LiveDot tone={g.tone}/></span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[13.5px] text-white/90">{g.name}</div>
                  <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/45">{g.role}</div>
                </div>
                <div className="text-right">
                  <div className="font-mono text-[11px] text-white/85 tabular">{g.rps.toFixed(1)}<span className="text-white/40"> rps</span></div>
                  <div className="font-mono text-[10px] text-white/45">{fmt.dollar(g.cost)}/h</div>
                </div>
              </button>
            ))}
          </div>
        </Card>

        {/* Detail */}
        <div className="col-span-12 lg:col-span-8 space-y-5">
          <div className="glass p-6 ring-aurora">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl glass-strong grid place-items-center" style={{ boxShadow: "0 0 30px -6px #5BD4FF" }}>
                  <Icon.Bot/>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <div className="text-[24px] tracking-[-0.02em] font-medium">{a.name}</div>
                    <Pill tone={a.tone}><LiveDot tone={a.tone}/> {a.status.toUpperCase()}</Pill>
                  </div>
                  <div className="font-mono text-[11px] uppercase tracking-[0.16em] text-white/45 mt-0.5">{a.role}</div>
                  <div className="text-[13.5px] text-white/70 mt-2 italic">"{a.thought}"<span className="caret" style={{ background: '#5BD4FF' }}/></div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Btn icon={<Icon.Pause/>}>Pause</Btn>
                <Btn tone="secondary" icon={<Icon.Code/>}>Inspect</Btn>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4 mt-6">
              <div>
                <div className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/45">cpu</div>
                <div className="text-[22px] mt-1 font-medium tabular">{cpu.toFixed(0)}%</div>
                <div className="h-1 rounded-full bg-white/[0.05] mt-2"><div className="h-full rounded-full" style={{ width: `${cpu}%`, background: "linear-gradient(90deg, #5BD4FF33, #5BD4FF)" }}/></div>
              </div>
              <div>
                <div className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/45">mem</div>
                <div className="text-[22px] mt-1 font-medium tabular">{mem.toFixed(0)}%</div>
                <div className="h-1 rounded-full bg-white/[0.05] mt-2"><div className="h-full rounded-full" style={{ width: `${mem}%`, background: "linear-gradient(90deg, #5C7BFF33, #5C7BFF)" }}/></div>
              </div>
              <div>
                <div className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/45">p99</div>
                <div className="text-[22px] mt-1 font-medium tabular">{a.p99}ms</div>
                <div className="font-mono text-[10.5px] text-white/45 mt-1">budget 800ms</div>
              </div>
              <div>
                <div className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/45">spend / h</div>
                <div className="text-[22px] mt-1 font-medium tabular">{fmt.dollar(a.cost)}</div>
                <div className="font-mono text-[10.5px] text-white/45 mt-1">budget $2.50</div>
              </div>
            </div>

            <div className="mt-5">
              <div className="flex items-center justify-between mb-2">
                <div className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/45">throughput · last 60s</div>
                <div className="font-mono text-[11px] text-white/55">tok/s {(a.rps * 38).toFixed(0)}</div>
              </div>
              <AreaChart data={traffic} h={120}/>
            </div>
          </div>

          <Card eyebrow="TRACE" title="Live thought · concierge → fleet" right={<Pill tone="cyan"><LiveDot tone="cyan"/> recording</Pill>}>
            <div className="space-y-2 font-mono text-[12px]">
              {trace.map((row, i) => (
                <div key={i} className="grid grid-cols-[80px_72px_1fr] gap-3 items-center reveal" style={{ animationDelay: `${i * 80}ms` }}>
                  <div className="text-white/40 tabular">{row.t}</div>
                  <Pill tone={row.k === 'spawn' ? 'azure' : row.k === 'memory' ? 'cyan' : row.k === 'tool' ? 'warn' : 'default'}>{row.k}</Pill>
                  <div className="text-white/85">{row.v}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* =========================================================
   SCREEN 3 — MEMORY GRAPH
   ========================================================= */
function MemoryGraph() {
  const W = 760, H = 460;
  const nodes = useMemo(() => ([
    { id: "halim",     x: W/2, y: H/2, r: 22, t: "self",     label: "Halim",         tone: "cyan" },
    { id: "work",      x: 200, y: 140, r: 16, t: "context",  label: "work",          tone: "azure" },
    { id: "family",    x: 560, y: 130, r: 16, t: "context",  label: "family",        tone: "azure" },
    { id: "health",    x: 180, y: 340, r: 16, t: "context",  label: "health",        tone: "azure" },
    { id: "ideas",     x: 580, y: 340, r: 16, t: "context",  label: "ideas",         tone: "azure" },
    { id: "nora",      x: 100, y: 80,  r: 11, t: "person",   label: "Nora",          tone: "default" },
    { id: "sam",       x: 280, y: 60,  r: 11, t: "person",   label: "Sam",           tone: "default" },
    { id: "amira",     x: 640, y: 60,  r: 11, t: "person",   label: "Amira",         tone: "default" },
    { id: "q3plan",    x: 130, y: 220, r: 13, t: "doc",      label: "q3-plan",       tone: "warn" },
    { id: "ai-os",     x: 300, y: 200, r: 14, t: "project",  label: "ai-os",         tone: "cyan" },
    { id: "sleep",     x: 100, y: 400, r: 11, t: "metric",   label: "sleep",         tone: "pos" },
    { id: "run",       x: 260, y: 400, r: 11, t: "metric",   label: "5km loop",      tone: "pos" },
    { id: "patent",    x: 660, y: 220, r: 13, t: "doc",      label: "patent-draft",  tone: "warn" },
    { id: "trip",      x: 720, y: 80,  r: 11, t: "event",    label: "lisbon trip",   tone: "default" },
    { id: "novel",     x: 700, y: 400, r: 13, t: "doc",      label: "the_novel.md",  tone: "warn" },
    { id: "github",    x: 380, y: 340, r: 11, t: "tool",     label: "github",        tone: "default" },
  ]), []);
  const edges = [
    ["halim","work"],["halim","family"],["halim","health"],["halim","ideas"],
    ["work","nora"],["work","sam"],["work","ai-os"],["work","q3plan"],
    ["family","amira"],["family","trip"],
    ["health","sleep"],["health","run"],
    ["ideas","novel"],["ideas","patent"],
    ["ai-os","github"],
    ["work","github"],
  ];
  const [hover, setHover] = useState(null);
  const [pulse, setPulse] = useState(0);
  useEffect(() => { const id = setInterval(() => setPulse(p => (p+1) % 1000), 90); return () => clearInterval(id); }, []);

  const colorOf = (tone) => ({ cyan: "#5BD4FF", azure: "#5C7BFF", warn: "#FFC56B", pos: "#5EE7A8", default: "rgba(255,255,255,0.7)" })[tone];
  const node = (id) => nodes.find(n => n.id === id);

  const stats = [
    { k: "entities", v: "1,284" },
    { k: "edges",    v: "3,902" },
    { k: "subgraphs",v: "14" },
    { k: "drift",    v: "0.04" },
  ];

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="02 · MEMORY"
        title="Memory graph"
        sub="A living map of what your assistant knows about you. Entities, contexts, projects, people — all dynamically linked."
        right={
          <div className="flex items-center gap-2">
            <div className="glass-strong rounded-[10px] flex items-center gap-2 px-3 h-9">
              <Icon.Search/>
              <input className="bg-transparent text-[13px] placeholder:text-white/35 w-56" placeholder="search memory · 1,284 entities" defaultValue="q3-plan" />
              <Pill>⌘K</Pill>
            </div>
            <Btn tone="primary" icon={<Icon.Plus/>}>Add entity</Btn>
          </div>
        }
      />

      <div className="grid grid-cols-12 gap-5">
        <Card className="col-span-12 lg:col-span-8 overflow-hidden" eyebrow="GRAPH" title="halim · self · root subgraph" right={<div className="flex gap-2"><Pill tone="cyan"><LiveDot tone="cyan"/> 7 NEW TODAY</Pill><Pill>5d window</Pill></div>}>
            <div className="relative h-[480px] rounded-[14px] overflow-hidden" style={{
              background: "radial-gradient(620px 360px at 40% 50%, rgba(91,212,255,0.06), transparent 70%), linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0))",
              border: "1px solid rgba(255,255,255,0.05)",
            }}>
              <svg viewBox={`0 0 ${W} ${H}`} className="absolute inset-0 w-full h-full">
                <defs>
                  <radialGradient id="halo" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#5BD4FF" stopOpacity="0.22"/>
                    <stop offset="100%" stopColor="#5BD4FF" stopOpacity="0"/>
                  </radialGradient>
                </defs>
                <circle cx={W/2} cy={H/2} r="160" fill="url(#halo)"/>
                {edges.map(([a, b], i) => {
                  const A = node(a), B = node(b);
                  const dash = (i + pulse) % 28;
                  return <line key={i} x1={A.x} y1={A.y} x2={B.x} y2={B.y} stroke="rgba(91,212,255,0.18)" strokeWidth="1" strokeDasharray="2 6" strokeDashoffset={-dash}/>;
                })}
                {nodes.map(n => (
                  <g key={n.id} onMouseEnter={() => setHover(n.id)} onMouseLeave={() => setHover(null)} style={{ cursor: 'pointer' }}>
                    <circle cx={n.x} cy={n.y} r={n.r + 6} fill={colorOf(n.tone)} fillOpacity="0.10"/>
                    <circle cx={n.x} cy={n.y} r={n.r} fill="#0F131C" stroke={colorOf(n.tone)} strokeWidth="1.5" style={{ filter: `drop-shadow(0 0 8px ${colorOf(n.tone)})` }}/>
                    {n.id === 'halim' && <circle cx={n.x} cy={n.y} r={n.r-6} fill={colorOf(n.tone)} fillOpacity="0.4"/>}
                    <text x={n.x} y={n.y + n.r + 14} fontFamily="Geist Mono" fontSize="10" fill={hover === n.id ? "#fff" : "rgba(255,255,255,0.55)"} textAnchor="middle" style={{ letterSpacing: 1 }}>{n.label}</text>
                  </g>
                ))}
              </svg>

              {/* Legend */}
              <div className="absolute bottom-3 left-3 flex gap-3 font-mono text-[10.5px] uppercase tracking-[0.14em]">
                <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-cyan-glow" style={{ boxShadow: "0 0 6px #5BD4FF" }}/>self</span>
                <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: "#5C7BFF", boxShadow: "0 0 6px #5C7BFF" }}/>context</span>
                <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: "#FFC56B", boxShadow: "0 0 6px #FFC56B" }}/>doc</span>
                <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: "#5EE7A8", boxShadow: "0 0 6px #5EE7A8" }}/>metric</span>
              </div>

              {/* Hover card */}
              {hover && (
                <div className="absolute top-3 right-3 glass p-3 w-60 ring-aurora">
                  <div className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/45">node · {node(hover).t}</div>
                  <div className="text-[15px] mt-0.5">{node(hover).label}</div>
                  <div className="text-[12px] text-white/55 mt-1">connected to {edges.filter(e => e[0] === hover || e[1] === hover).length} entities</div>
                </div>
              )}
            </div>
        </Card>

        <div className="col-span-12 lg:col-span-4 space-y-5">
          <Card eyebrow="TELEMETRY" title="Subgraph health">
            <div className="grid grid-cols-2 gap-3">
              {stats.map((s, i) => (
                <div key={i} className="glass-strong rounded-[12px] p-3">
                  <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/45">{s.k}</div>
                  <div className="text-[20px] mt-1 tabular">{s.v}</div>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <div className="flex items-center justify-between mb-1.5">
                <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/45">recall confidence</div>
                <div className="font-mono text-[11px] text-cyan-glow tabular">94.2%</div>
              </div>
              <div className="h-1.5 rounded-full bg-white/[0.05]"><div className="h-full rounded-full" style={{ width: "94.2%", background: "linear-gradient(90deg, #5BD4FF33, #5BD4FF)" }}/></div>
            </div>
          </Card>

          <Card eyebrow="JOURNAL" title="Today's memory ops">
            <div className="space-y-2.5">
              {[
                ["+", "ai-os/auth.md → linked to ai-os", "cyan"],
                ["~", "merged 'q3-planning' (47 → 39)", "azure"],
                ["+", "lisbon trip → family", "default"],
                ["−", "expired stale: 'old-domain'", "warn"],
                ["+", "sleep: 7h 12m last night", "pos"],
              ].map((r, i) => (
                <div key={i} className="flex items-center gap-3 text-[13px]">
                  <span className={`font-mono w-4 text-center ${r[2] === 'cyan' ? 'text-cyan-glow' : r[2] === 'azure' ? 'text-[#A8B7FF]' : r[2] === 'warn' ? 'text-[#FFC56B]' : r[2] === 'pos' ? 'text-[#5EE7A8]' : 'text-white/55'}`}>{r[0]}</span>
                  <div className="flex-1 text-white/82 truncate">{r[1]}</div>
                  <div className="font-mono text-[10.5px] text-white/40">{i*3+1}m</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

window.CommandCenter = CommandCenter;
window.AgentMonitoring = AgentMonitoring;
window.MemoryGraph = MemoryGraph;
