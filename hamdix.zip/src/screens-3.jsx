// Screens 7-10: API Playground, Workflow Builder, Deployment Center, Productivity Hub
const { useState, useEffect, useRef, useMemo } = React;

/* =========================================================
   SCREEN 7 — API PLAYGROUND
   ========================================================= */
function ApiPlayground() {
  const [tab, setTab] = useState("body");
  const [streaming, setStreaming] = useState(false);
  const responseText = useTyper(
    streaming
      ? `{\n  "id": "msg_01HXGT…",\n  "model": "claude-sonnet-4.5",\n  "stop_reason": "end_turn",\n  "content": [\n    { "type": "text", "text": "Indexed 142 messages. Three actionable: Sam's worker-pool patch, Nora's slip, Amira's dinner. Drafted replies." }\n  ],\n  "usage": { "input_tokens": 482, "output_tokens": 128 }\n}`
      : "",
    { speed: 8 }
  );

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="06 · DEVTOOLS"
        title="API playground"
        sub="Compose and stream against any agent endpoint. Request, response, headers, traces — all in one keyboard-driven surface."
        right={
          <div className="flex items-center gap-2">
            <Pill tone="cyan">workspace · halim/dev</Pill>
            <Btn icon={<Icon.Code/>}>cURL</Btn>
            <Btn icon={<Icon.Plus/>}>Save preset</Btn>
          </div>
        }
      />

      <div className="grid grid-cols-12 gap-5">
        {/* Request */}
        <Card className="col-span-12 lg:col-span-7" eyebrow="REQUEST" title="POST /api/v1/agents/concierge/run" right={<Pill tone="pos">200 · 412ms</Pill>}>
          {/* Verb + URL */}
          <div className="glass-strong rounded-[12px] p-1 flex items-center gap-1">
            <span className="px-3 py-1.5 rounded-md bg-cyan-glow/15 text-cyan-glow font-mono text-[12px] tracking-wider">POST</span>
            <input
              defaultValue="https://api.hamdix.dev/v1/agents/concierge/run"
              className="flex-1 px-2 font-mono text-[13px]"/>
            <Btn tone="primary" icon={<Icon.Send/>} onClick={() => setStreaming(true)}>{streaming ? "Streaming…" : "Send"}</Btn>
          </div>

          {/* Tabs */}
          <div className="mt-4 border-b border-white/[0.06] flex gap-5">
            {["body","headers","auth","params","traces"].map(t => (
              <button key={t} onClick={() => setTab(t)} className={`relative pb-2 font-mono text-[11.5px] uppercase tracking-[0.14em] ${tab === t ? 'text-cyan-glow' : 'text-white/45 hover:text-white/85'}`}>
                {t}
                {tab === t && <span className="absolute -bottom-px left-0 right-0 h-px bg-cyan-glow" style={{ boxShadow: "0 0 8px #5BD4FF" }}/>}
              </button>
            ))}
          </div>

          {/* Body */}
          <div className="mt-4 glass-strong rounded-[12px] p-4 font-mono text-[12.5px] leading-[1.7] whitespace-pre">
<span className="text-white/40">{`// json · request body`}</span>{`\n`}
<span className="text-white/55">{`{`}</span>{`\n`}
<span>  <span className="text-cyan-glow">"intent"</span>: <span className="text-[#FFC56B]">"/daily-kickoff"</span>,</span>{`\n`}
<span>  <span className="text-cyan-glow">"context"</span>: <span className="text-[#FFC56B]">"morning"</span>,</span>{`\n`}
<span>  <span className="text-cyan-glow">"chains"</span>: [<span className="text-[#FFC56B]">"telegram.read"</span>, <span className="text-[#FFC56B]">"scribe.compose"</span>],</span>{`\n`}
<span>  <span className="text-cyan-glow">"budget"</span>: <span className="text-[#A8B7FF]">0.40</span>,</span>{`\n`}
<span>  <span className="text-cyan-glow">"stream"</span>: <span className="text-[#5EE7A8]">true</span></span>{`\n`}
<span className="text-white/55">{`}`}</span>
          </div>

          {/* Quick actions */}
          <div className="flex items-center gap-2 mt-4">
            <Pill tone="cyan">⌘ ↵ to send</Pill>
            <Pill>⌘ K · search agents</Pill>
            <Pill>⌥ ↑ · prev preset</Pill>
          </div>
        </Card>

        {/* Response */}
        <Card className="col-span-12 lg:col-span-5" eyebrow="RESPONSE" title="streaming · sse" right={<div className="flex gap-2"><Pill tone={streaming ? "cyan" : "default"}>{streaming ? <><LiveDot tone="cyan"/> 412ms</> : "idle"}</Pill><Pill>128 tok</Pill></div>}>
          <div className="glass-strong rounded-[12px] p-4 font-mono text-[12px] leading-[1.65] min-h-[260px] whitespace-pre-wrap">
            {streaming ? <>{responseText}<span className="caret"/></> : <span className="text-white/40">{`// click "Send" to stream a response`}</span>}
          </div>
          <div className="grid grid-cols-3 gap-3 mt-4 font-mono text-[11px]">
            <div><div className="text-white/45">ttf</div><div className="text-cyan-glow tabular">312ms</div></div>
            <div><div className="text-white/45">total</div><div className="text-white tabular">412ms</div></div>
            <div><div className="text-white/45">cost</div><div className="text-white tabular">$0.018</div></div>
          </div>
        </Card>

        {/* Trace timeline */}
        <Card className="col-span-12" eyebrow="TRACE" title="Request waterfall" right={<Pill tone="cyan">412ms total</Pill>}>
          <div className="space-y-2.5">
            {[
              { label: "POST /run", color: "#5BD4FF", start: 0, dur: 12 },
              { label: "auth.verify", color: "#5C7BFF", start: 4, dur: 8 },
              { label: "router.resolve → concierge", color: "#5BD4FF", start: 14, dur: 24 },
              { label: "memory.load(work)", color: "#9D7BFF", start: 38, dur: 80 },
              { label: "tool.telegram.read", color: "#FFC56B", start: 118, dur: 180 },
              { label: "model.sonnet-4.5 · stream start", color: "#5EE7A8", start: 312, dur: 100 },
            ].map((r, i) => (
              <div key={i} className="grid grid-cols-[200px_1fr_80px] items-center gap-3 reveal" style={{ animationDelay: `${i * 60}ms` }}>
                <div className="font-mono text-[11.5px] text-white/75 truncate">{r.label}</div>
                <div className="relative h-5 bg-white/[0.04] rounded-full overflow-hidden">
                  <div className="absolute top-0 bottom-0 rounded-full" style={{
                    left: `${(r.start / 412) * 100}%`,
                    width: `${(r.dur / 412) * 100}%`,
                    background: `linear-gradient(90deg, ${r.color}66, ${r.color})`,
                    boxShadow: `0 0 12px -2px ${r.color}`,
                  }}/>
                </div>
                <div className="font-mono text-[11px] text-right text-white/70 tabular">{r.dur}ms</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

/* =========================================================
   SCREEN 8 — WORKFLOW BUILDER
   ========================================================= */
function WorkflowBuilder() {
  // Simple node graph
  const W = 880, H = 420;
  const nodes = [
    { id: "trigger", x: 60,  y: 60,  w: 200, h: 78, kind: "trigger", title: "Telegram message", sub: "from any watched chat", tone: "cyan" },
    { id: "filter",  x: 320, y: 60,  w: 200, h: 78, kind: "filter",  title: "If contains decision", sub: "scout.classify", tone: "azure" },
    { id: "memory",  x: 580, y: 60,  w: 200, h: 78, kind: "memory",  title: "Save to memory", sub: "context: work", tone: "aurora" },
    { id: "split",   x: 320, y: 200, w: 200, h: 78, kind: "branch",  title: "If /daily-kickoff", sub: "intent matcher", tone: "cyan" },
    { id: "scribe",  x: 580, y: 200, w: 200, h: 78, kind: "agent",   title: "Compose brief", sub: "scribe · sonnet-4.5", tone: "cyan" },
    { id: "approve", x: 60,  y: 200, w: 200, h: 78, kind: "human",   title: "Human approval", sub: "@halim · 30s window", tone: "warn" },
    { id: "send",    x: 580, y: 320, w: 200, h: 78, kind: "send",    title: "Reply on Telegram", sub: "via @hamdix_bot", tone: "pos" },
  ];
  const edges = [
    ["trigger","filter"],
    ["filter","memory"],
    ["filter","split"],
    ["split","scribe"],
    ["scribe","send"],
    ["scribe","approve"],
  ];
  const colorOf = (tone) => ({ cyan: "#5BD4FF", azure: "#5C7BFF", aurora: "#9D7BFF", warn: "#FFC56B", pos: "#5EE7A8" })[tone];
  const node = (id) => nodes.find(n => n.id === id);

  const palette = [
    { k: "Trigger",  items: ["Telegram message","Cron schedule","Webhook","Queue job"], tone: "cyan" },
    { k: "Logic",    items: ["If / else","Switch","Loop","Wait"], tone: "azure" },
    { k: "Agent",    items: ["concierge.route","scribe.compose","scout.classify","ledger.reconcile"], tone: "aurora" },
    { k: "Action",   items: ["Telegram reply","Save memory","Github comment","Run script"], tone: "pos" },
  ];

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="07 · COMPOSE"
        title="Workflow builder"
        sub="Wire triggers, filters, agents, and actions into reusable flows. Run them from cron, webhook, or a single Telegram command."
        right={
          <div className="flex items-center gap-2">
            <Pill tone="pos">draft · /daily-kickoff</Pill>
            <Btn icon={<Icon.Play/>}>Test run</Btn>
            <Btn tone="primary" icon={<Icon.Rocket/>}>Publish</Btn>
          </div>
        }
      />

      <div className="grid grid-cols-12 gap-5">
        {/* Palette */}
        <Card className="col-span-12 lg:col-span-3" eyebrow="PALETTE" title="Drop in">
          <div className="space-y-4">
            {palette.map((p, i) => (
              <div key={i}>
                <div className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/45 mb-2">{p.k}</div>
                <div className="space-y-1.5">
                  {p.items.map((t, ti) => (
                    <div key={ti} className="glass-strong rounded-[10px] px-3 py-2 flex items-center gap-2 text-[12.5px] hover:border-white/[0.18] cursor-grab transition reveal" style={{ animationDelay: `${(i*4+ti) * 30}ms` }}>
                      <span className="w-1.5 h-1.5 rounded-full" style={{ background: colorOf(p.tone), boxShadow: `0 0 6px ${colorOf(p.tone)}` }}/>
                      <span className="text-white/82">{t}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Canvas */}
        <Card className="col-span-12 lg:col-span-9 overflow-hidden" eyebrow="CANVAS" title="/daily-kickoff" right={<div className="flex gap-2"><Pill>v 0.4 draft</Pill><Pill tone="cyan">7 nodes · 6 edges</Pill></div>}>
          <div className="relative h-[460px] rounded-[14px] overflow-hidden" style={{
            background: "radial-gradient(800px 320px at 30% 20%, rgba(91,212,255,0.05), transparent 60%)",
            border: "1px solid rgba(255,255,255,0.05)",
            backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.05) 1px, transparent 1px)",
            backgroundSize: "20px 20px",
          }}>
            <svg viewBox={`0 0 ${W} ${H}`} className="absolute inset-0 w-full h-full">
              {/* edges */}
              {edges.map(([a,b], i) => {
                const A = node(a), B = node(b);
                const x1 = A.x + A.w, y1 = A.y + A.h/2;
                const x2 = B.x, y2 = B.y + B.h/2;
                const cx = (x1 + x2) / 2;
                const path = `M${x1} ${y1} C${cx} ${y1}, ${cx} ${y2}, ${x2} ${y2}`;
                return (
                  <g key={i}>
                    <path d={path} stroke={colorOf(B.tone)} strokeWidth="1.5" fill="none" opacity="0.4" />
                    <path d={path} stroke={colorOf(B.tone)} strokeWidth="1.5" fill="none" strokeDasharray="4 8" opacity="0.85" style={{ filter: `drop-shadow(0 0 4px ${colorOf(B.tone)})` }}>
                      <animate attributeName="stroke-dashoffset" from="0" to="-24" dur="1.2s" repeatCount="indefinite"/>
                    </path>
                    <circle cx={x2-4} cy={y2} r="3" fill={colorOf(B.tone)} style={{ filter: `drop-shadow(0 0 4px ${colorOf(B.tone)})` }}/>
                  </g>
                );
              })}
              {/* nodes */}
              {nodes.map(n => {
                const c = colorOf(n.tone);
                return (
                  <g key={n.id}>
                    <rect x={n.x} y={n.y} width={n.w} height={n.h} rx="14" fill="rgba(15,19,28,0.85)" stroke={c} strokeOpacity="0.55" />
                    <rect x={n.x} y={n.y} width={n.w} height={n.h} rx="14" fill="none" stroke={c} strokeOpacity="0.18" strokeWidth="3" style={{ filter: `blur(6px)` }}/>
                    <text x={n.x+16} y={n.y+22} fontFamily="Geist Mono" fontSize="9" fill="rgba(255,255,255,0.45)" letterSpacing="2">{n.kind.toUpperCase()}</text>
                    <text x={n.x+16} y={n.y+44} fontFamily="Geist" fontSize="14" fill="rgba(255,255,255,0.92)">{n.title}</text>
                    <text x={n.x+16} y={n.y+64} fontFamily="Geist" fontSize="11.5" fill="rgba(255,255,255,0.55)">{n.sub}</text>
                    <circle cx={n.x} cy={n.y+n.h/2} r="4" fill="#0F131C" stroke={c}/>
                    <circle cx={n.x+n.w} cy={n.y+n.h/2} r="4" fill={c} style={{ filter: `drop-shadow(0 0 4px ${c})` }}/>
                  </g>
                );
              })}
            </svg>
          </div>
          <div className="grid grid-cols-4 gap-3 mt-4 font-mono text-[11px]">
            <div><div className="text-white/45">last run</div><div className="text-white tabular">07:00 · today</div></div>
            <div><div className="text-white/45">success rate · 30d</div><div className="text-[#5EE7A8] tabular">98.2%</div></div>
            <div><div className="text-white/45">avg duration</div><div className="text-white tabular">3.4s</div></div>
            <div><div className="text-white/45">avg cost</div><div className="text-white tabular">$0.18</div></div>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* =========================================================
   SCREEN 9 — DEPLOYMENT CENTER
   ========================================================= */
function DeploymentCenter() {
  const envs = [
    { name: "production", url: "hamdix.dev", region: "fsn1", commit: "9e34a82", status: "healthy", workers: 8, cpu: 24, build: "2m 14s", deployed: "12m ago", tone: "pos" },
    { name: "staging",    url: "stg.hamdix.dev", region: "ash1", commit: "f1c8d20", status: "deploying", workers: 4, cpu: 71, build: "1m 02s", deployed: "now", tone: "cyan" },
    { name: "preview",    url: "pr-412.hamdix.dev", region: "fsn1", commit: "a44b912", status: "healthy", workers: 1, cpu: 12, build: "0m 48s", deployed: "1h ago", tone: "azure" },
  ];
  const buildLog = useTyper(
    "▸ resolving composer deps…\n▸ php artisan octane:reload\n▸ migrating: 2026_05_09_184_addModelRoutingPolicy\n▸ horizon: scaling supervisors (4→8)\n▸ syncing livewire assets…\n▸ tailwind: 312 utilities purged\n✓ build green · pushing image\n✓ image: hamdix/api:9e34a82\n▸ rolling out staging · 1/4 …",
    { speed: 12 }
  );
  const cpu = useTicker(56, { step: 4, period: 700 });

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="08 · SHIPYARD"
        title="Deployment center"
        sub="Three environments. One pipeline. Octane workers, Horizon, queues, and the migrations that keep them aligned."
        right={
          <div className="flex items-center gap-2">
            <Pill tone="cyan">main · 9e34a82</Pill>
            <Btn icon={<Icon.Code/>}>Open repo</Btn>
            <Btn tone="primary" icon={<Icon.Rocket/>}>Deploy main → prod</Btn>
          </div>
        }
      />

      <div className="grid grid-cols-12 gap-5">
        {envs.map((e, i) => (
          <Card key={i} className={`col-span-12 lg:col-span-4 ${e.status === 'deploying' ? 'ring-aurora underglow-cyan' : ''}`} eyebrow={e.region.toUpperCase()} title={
            <div className="flex items-center gap-2">
              <span>{e.name}</span>
              <Pill tone={e.tone}>{e.status === 'deploying' && <LiveDot tone="cyan"/>}{e.status}</Pill>
            </div>
          } right={<button className="text-white/40 hover:text-white"><Icon.Globe/></button>}>
            <div className="font-mono text-[11.5px] text-white/55">{e.url}</div>
            <div className="grid grid-cols-2 gap-3 mt-4">
              <div className="glass-strong rounded-[10px] p-3">
                <div className="font-mono text-[10px] uppercase tracking-[0.14em] text-white/40">commit</div>
                <div className="font-mono text-[12.5px] text-white/85 mt-0.5">{e.commit}</div>
              </div>
              <div className="glass-strong rounded-[10px] p-3">
                <div className="font-mono text-[10px] uppercase tracking-[0.14em] text-white/40">workers</div>
                <div className="text-[16px] tabular mt-0.5">{e.workers}</div>
              </div>
              <div className="glass-strong rounded-[10px] p-3">
                <div className="font-mono text-[10px] uppercase tracking-[0.14em] text-white/40">cpu</div>
                <div className="text-[16px] tabular mt-0.5">{e.status === 'deploying' ? cpu.toFixed(0) : e.cpu}%</div>
              </div>
              <div className="glass-strong rounded-[10px] p-3">
                <div className="font-mono text-[10px] uppercase tracking-[0.14em] text-white/40">deployed</div>
                <div className="text-[12.5px] mt-0.5">{e.deployed}</div>
              </div>
            </div>
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-2 font-mono text-[10.5px] text-white/45 uppercase tracking-[0.14em]">
                <span>build {e.build}</span>
              </div>
              <div className="flex gap-2"><Btn>Rollback</Btn>{e.status !== 'deploying' && <Btn tone="secondary">Promote</Btn>}</div>
            </div>
          </Card>
        ))}

        {/* Pipeline */}
        <Card className="col-span-12 lg:col-span-7" eyebrow="PIPELINE" title="ai/concierge#412 · staging" right={<Pill tone="cyan"><LiveDot tone="cyan"/> 04:18 elapsed</Pill>}>
          <div className="grid grid-cols-6 gap-2">
            {[
              { k: "lint", st: "done", t: "8s" },
              { k: "test", st: "done", t: "1m 04s" },
              { k: "build", st: "done", t: "2m 14s" },
              { k: "migrate", st: "running", t: "—" },
              { k: "deploy", st: "queued", t: "—" },
              { k: "smoke", st: "queued", t: "—" },
            ].map((s, i) => {
              const tone = s.st === 'done' ? 'pos' : s.st === 'running' ? 'cyan' : 'default';
              return (
                <div key={i} className="glass-strong rounded-[10px] p-3 reveal" style={{ animationDelay: `${i * 70}ms` }}>
                  <div className="flex items-center justify-between">
                    <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-white/65">{s.k}</div>
                    {s.st === 'running' ? <LiveDot tone="cyan"/> : s.st === 'done' ? <Icon.Check/> : <span className="w-1.5 h-1.5 rounded-full bg-white/20"/>}
                  </div>
                  <div className="font-mono text-[11px] text-white/45 mt-2">{s.t}</div>
                </div>
              );
            })}
          </div>

          <div className="mt-5 rounded-[12px] glass-strong p-4 font-mono text-[12px] leading-[1.65] whitespace-pre-wrap text-white/82 max-h-[180px] overflow-y-auto">
            {buildLog}<span className="caret"/>
          </div>
        </Card>

        <Card className="col-span-12 lg:col-span-5" eyebrow="HEALTH" title="Production · last 60 minutes">
          <div className="grid grid-cols-2 gap-3">
            <div className="glass-strong rounded-[12px] p-3">
              <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/45">request rate</div>
              <div className="text-[22px] tabular mt-1">142<span className="text-[12px] text-white/45">/min</span></div>
              <AreaChart data={genWalk(40, 0.5, 5)} h={50}/>
            </div>
            <div className="glass-strong rounded-[12px] p-3">
              <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/45">p99 latency</div>
              <div className="text-[22px] tabular mt-1">412<span className="text-[12px] text-white/45">ms</span></div>
              <AreaChart data={genWalk(40, 0.4, 6)} h={50} color="#5C7BFF" color2="#5C7BFF"/>
            </div>
            <div className="glass-strong rounded-[12px] p-3">
              <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/45">error rate</div>
              <div className="text-[22px] tabular mt-1">0.04<span className="text-[12px] text-white/45">%</span></div>
              <AreaChart data={genWalk(40, 0.7, 4)} h={50} color="#5EE7A8" color2="#5EE7A8"/>
            </div>
            <div className="glass-strong rounded-[12px] p-3">
              <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/45">queue depth</div>
              <div className="text-[22px] tabular mt-1">18</div>
              <AreaChart data={genWalk(40, 0.6, 7)} h={50} color="#FFC56B" color2="#FFC56B"/>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* =========================================================
   SCREEN 10 — PERSONAL PRODUCTIVITY HUB
   ========================================================= */
function ProductivityHub() {
  const blocks = [
    { t: "07:00", l: "/daily-kickoff", k: "ritual",  done: true,  agent: "concierge" },
    { t: "08:30", l: "Strength · pull",  k: "body",  done: true,  agent: "—" },
    { t: "10:00", l: "Deep work · ai-os auth flow", k: "focus", agent: "scribe", current: true },
    { t: "12:30", l: "Lunch + walk · Lisbon notes", k: "rest", agent: "—" },
    { t: "14:00", l: "1:1 with Sam · worker-pool", k: "meet", agent: "wren" },
    { t: "15:30", l: "Patent draft · sec. 4", k: "focus", agent: "scribe" },
    { t: "17:30", l: "Inbox triage · /summarize", k: "ritual", agent: "concierge" },
    { t: "19:30", l: "Dinner · Amira", k: "life", agent: "—" },
  ];
  const habits = [
    { name: "sleep ≥ 7h", done: 6, total: 7, tone: "cyan" },
    { name: "5km run",    done: 4, total: 5, tone: "azure" },
    { name: "no doomscroll after 22h", done: 5, total: 7, tone: "warn" },
    { name: "1 hour reading", done: 7, total: 7, tone: "pos" },
  ];
  const focus = useTicker(72, { step: 2, period: 1000, min: 40, max: 96 });
  const sleep = 7.2;
  const hrv = 64;

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="09 · LIFE"
        title={<>The <span className="font-serif italic">human</span> layer</>}
        sub="Your assistant earns its keep here — guarding focus, holding rituals, watching the body. Not a CRM. Not a productivity cult."
        right={<div className="flex items-center gap-2"><Pill tone="cyan"><LiveDot tone="cyan"/> FOCUS · 72%</Pill><Btn icon={<Icon.Pause/>}>Pause day</Btn></div>}
      />

      <div className="grid grid-cols-12 gap-5">
        {/* Focus card */}
        <div className="col-span-12 lg:col-span-4 glass p-6 ring-aurora underglow-azure">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/45">focus index · live</div>
              <div className="text-[64px] tracking-[-0.03em] font-medium tabular leading-none mt-2">{focus.toFixed(0)}<span className="text-[18px] text-white/40">/100</span></div>
            </div>
            <Donut value={focus} size={92} stroke={7} color="#5C7BFF" label={<div className="font-serif italic text-cyan-glow text-[15px]">flow</div>}/>
          </div>
          <div className="text-[13px] text-white/65 mt-3 leading-relaxed">You're 47 minutes into a deep-work block. Notifications muted, Telegram triaged, Sam's question buffered for 14:00.</div>
          <div className="grid grid-cols-3 gap-3 mt-5 font-mono text-[11px]">
            <div><div className="text-white/45">deep min · today</div><div className="text-cyan-glow tabular">214</div></div>
            <div><div className="text-white/45">interrupts</div><div className="text-white tabular">2</div></div>
            <div><div className="text-white/45">streak</div><div className="text-[#5EE7A8] tabular">12d</div></div>
          </div>
        </div>

        {/* Day plan */}
        <Card className="col-span-12 lg:col-span-8" eyebrow="TODAY" title={<>Friday · <span className="font-serif italic text-white/70">May 9</span></>} right={<Pill tone="cyan">3 / 8 done</Pill>}>
          <div className="space-y-1">
            {blocks.map((b, i) => (
              <div key={i} className={`grid grid-cols-[60px_1fr_120px_24px] items-center gap-3 py-2.5 border-b border-white/[0.04] last:border-0 reveal ${b.current ? 'bg-cyan-glow/[0.04] -mx-2 px-2 rounded-[10px] border-cyan-glow/20' : ''}`} style={{ animationDelay: `${i * 60}ms` }}>
                <div className="font-mono text-[12px] text-white/55 tabular">{b.t}</div>
                <div className="flex items-center gap-3">
                  {b.done ? <span className="w-4 h-4 rounded-full grid place-items-center" style={{ background: "#5EE7A8", color: "#06080D" }}><Icon.Check/></span>
                    : b.current ? <LiveDot tone="cyan"/>
                    : <span className="w-3 h-3 rounded-full border border-white/20"/>}
                  <div>
                    <div className={`text-[14px] ${b.done ? 'text-white/50 line-through decoration-white/30' : 'text-white/92'}`}>{b.l}</div>
                    <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/40 mt-0.5">{b.k}</div>
                  </div>
                </div>
                <div>{b.agent !== "—" && <Pill tone="cyan">held by {b.agent}</Pill>}</div>
                <div><Icon.Arrow/></div>
              </div>
            ))}
          </div>
        </Card>

        {/* Body */}
        <Card className="col-span-12 lg:col-span-4" eyebrow="BODY" title="Last night">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/45">sleep</div>
              <div className="text-[32px] tracking-[-0.02em] mt-1 tabular">{sleep}<span className="text-[14px] text-white/45">h</span></div>
              <div className="text-[11.5px] text-[#5EE7A8] font-mono">▴ 0.4 vs 7d</div>
            </div>
            <div>
              <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/45">hrv</div>
              <div className="text-[32px] tracking-[-0.02em] mt-1 tabular">{hrv}<span className="text-[14px] text-white/45">ms</span></div>
              <div className="text-[11.5px] text-[#5EE7A8] font-mono">▴ steady</div>
            </div>
          </div>
          <div className="mt-4 h-12 flex items-end gap-1">
            {[40,55,30,68,72,90,80,72,55,42,30,28,22,30,52,72,82,90,76].map((v, i) => (
              <div key={i} className="flex-1 rounded-sm" style={{ height: `${v}%`, background: i < 4 ? 'linear-gradient(180deg, #5C7BFF, transparent)' : i < 12 ? 'linear-gradient(180deg, #5BD4FF, transparent)' : 'linear-gradient(180deg, #9D7BFF, transparent)' }}/>
            ))}
          </div>
          <div className="grid grid-cols-3 mt-1 font-mono text-[10px] text-white/40 uppercase tracking-[0.12em]">
            <div>deep</div><div className="text-center">light</div><div className="text-right">rem</div>
          </div>
        </Card>

        {/* Habits */}
        <Card className="col-span-12 lg:col-span-4" eyebrow="HABITS" title="This week">
          <div className="space-y-3.5">
            {habits.map((h, i) => (
              <div key={i}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="text-[13px] text-white/85">{h.name}</div>
                  <div className="font-mono text-[11px] text-white/55 tabular">{h.done}/{h.total}</div>
                </div>
                <div className="flex gap-1">
                  {Array.from({ length: h.total }).map((_, k) => (
                    <div key={k} className="flex-1 h-1.5 rounded-full" style={{
                      background: k < h.done ? `linear-gradient(90deg, ${h.tone === 'cyan' ? '#5BD4FF' : h.tone === 'azure' ? '#5C7BFF' : h.tone === 'warn' ? '#FFC56B' : '#5EE7A8'}55, ${h.tone === 'cyan' ? '#5BD4FF' : h.tone === 'azure' ? '#5C7BFF' : h.tone === 'warn' ? '#FFC56B' : '#5EE7A8'})` : 'rgba(255,255,255,0.05)',
                    }}/>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Journal */}
        <Card className="col-span-12 lg:col-span-4" eyebrow="JOURNAL" title="Halim · brief from atlas">
          <div className="text-[14px] leading-[1.65] text-white/82">
            <span className="font-serif italic text-cyan-glow">Yesterday you wrote:</span> "Lisbon is on the table for September — Amira wants to lock it before the kids' school starts." Atlas linked the trip to <span className="text-cyan-glow">family</span> and reminded you to ask Sam about the on-call rotation.
          </div>
          <div className="flex items-center gap-2 mt-4">
            <Btn icon={<Icon.Spark2/>}>Reflect</Btn>
            <Btn icon={<Icon.Plus/>}>Add note</Btn>
          </div>
        </Card>
      </div>
    </div>
  );
}

window.ApiPlayground = ApiPlayground;
window.WorkflowBuilder = WorkflowBuilder;
window.DeploymentCenter = DeploymentCenter;
window.ProductivityHub = ProductivityHub;
