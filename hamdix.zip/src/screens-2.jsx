// Screens 4-6: Telegram Console, Queue/Jobs, Cost Analytics
const { useState, useEffect, useRef, useMemo } = React;

/* =========================================================
   SCREEN 4 — TELEGRAM LIVE CONSOLE
   ========================================================= */
function TelegramConsole() {
  const chats = [
    { who: "@halim · self",   last: "draft: 'sounds good — Tuesday 19:30?'", t: "now",  unread: 0, tone: "cyan",   ai: true },
    { who: "@nora",           last: "we slipped a day, not blocking",        t: "2m",   unread: 3, tone: "default",ai: false },
    { who: "Family",          last: "amira: pictures from the park 📷",      t: "8m",   unread: 0, tone: "default",ai: false },
    { who: "@sam · ai-os",    last: "did the worker pool patch land?",       t: "12m",  unread: 1, tone: "azure",  ai: true },
    { who: "@halim → bot",    last: "/summarize today",                      t: "14m",  unread: 0, tone: "cyan",   ai: true },
    { who: "ledger · auto",   last: "spend ledger reconciled",               t: "1h",   unread: 0, tone: "pos",    ai: true },
    { who: "@amira",          last: "are we still on for dinner?",           t: "1h",   unread: 0, tone: "default",ai: false },
    { who: "scout · index",   last: "indexed 6 chats · 142 msgs",            t: "2h",   unread: 0, tone: "azure",  ai: true },
  ];
  const [sel, setSel] = useState(3);
  const [draft, setDraft] = useState("Yes — landed in `ai/concierge#412`. Want me to bump the worker count on staging tonight?");

  const messages = [
    { from: "Sam",   t: "11:42", text: "did the worker pool patch land?" },
    { from: "Sam",   t: "11:42", text: "saw the queue depth alert — wanted to confirm before I poke at it" },
    { from: "Halim · concierge", ai: true, t: "11:43", text: "I caught the alert too. Patch is in `ai/concierge#412` — merged 9 minutes ago. Sam, want me to draft a reply?" },
    { from: "Halim", t: "11:43", text: "yes, but ask before sending" },
    { from: "scribe · draft", ai: true, draft: true, t: "11:44", text: "Yes — landed in `ai/concierge#412`. Want me to bump the worker count on staging tonight?" },
  ];

  const liveTokens = useTicker(58, { step: 5, period: 600 });
  const sigs = useMemo(() => genWalk(48, 0.4, 7), []);

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="03 · CONVERSATIONAL"
        title="Telegram live console"
        sub="Your assistant runs inside Telegram — drafts, triages, schedules, summarizes. You stay in the loop without leaving the chat."
        right={
          <div className="flex items-center gap-2">
            <Pill tone="pos"><LiveDot/> WEBHOOK · OK</Pill>
            <Pill tone="cyan"><LiveDot tone="cyan"/> 14 MSG/MIN</Pill>
            <Btn icon={<Icon.Plus/>}>New thread</Btn>
          </div>
        }
      />

      <div className="grid grid-cols-12 gap-5">
        {/* Chat list */}
        <Card className="col-span-12 lg:col-span-3" eyebrow="THREADS" title="Watched chats">
          <div className="space-y-1">
            {chats.map((c, i) => (
              <button key={i} onClick={() => setSel(i)} className={`w-full text-left rounded-[10px] px-3 py-2.5 flex items-start gap-3 border transition ${i === sel ? 'bg-white/[0.06] border-cyan-glow/30' : 'border-transparent hover:bg-white/[0.03]'}`}>
                <div className="relative shrink-0">
                  <div className="w-8 h-8 rounded-full glass-strong grid place-items-center text-[11px] font-mono">{c.who.slice(0,1).toUpperCase()}</div>
                  {c.ai && <span className="absolute -bottom-0.5 -right-0.5"><LiveDot tone={c.tone === "default" ? "cyan" : c.tone}/></span>}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <div className="text-[13px] truncate">{c.who}</div>
                    <div className="font-mono text-[10px] text-white/40">{c.t}</div>
                  </div>
                  <div className="text-[12px] text-white/55 truncate">{c.last}</div>
                </div>
                {c.unread > 0 && <span className="shrink-0 text-[10px] font-mono px-1.5 rounded-full bg-cyan-glow text-[#06080D]">{c.unread}</span>}
              </button>
            ))}
          </div>
        </Card>

        {/* Conversation */}
        <Card className="col-span-12 lg:col-span-6" eyebrow="THREAD" title="@sam · ai-os" right={
          <div className="flex items-center gap-2">
            <Pill><Icon.Pin/> pinned</Pill>
            <Pill tone="cyan">auto-draft on</Pill>
          </div>
        }>
          <div className="space-y-4 max-h-[460px] overflow-y-auto pr-1">
            {messages.map((m, i) => (
              <div key={i} className={`flex gap-3 reveal ${m.from.includes("Halim") && !m.draft ? 'flex-row-reverse' : ''}`} style={{ animationDelay: `${i * 100}ms` }}>
                <div className="w-8 h-8 rounded-full glass-strong grid place-items-center text-[11px] font-mono shrink-0">{m.from[0]}</div>
                <div className={`max-w-[78%] ${m.from.includes("Halim") && !m.draft ? 'text-right' : ''}`}>
                  <div className="flex items-center gap-2 mb-1">
                    <div className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/45">{m.from}</div>
                    <div className="font-mono text-[10px] text-white/35">{m.t}</div>
                    {m.ai && <Pill tone="cyan">ai</Pill>}
                    {m.draft && <Pill tone="warn">awaiting approval</Pill>}
                  </div>
                  <div className={`px-3.5 py-2.5 rounded-[14px] text-[13.5px] leading-[1.55] ${
                    m.draft ? 'glass-strong border border-[#FFC56B]/30' :
                    m.ai ? 'glass-strong ring-aurora' :
                    m.from.includes("Halim") ? 'bg-cyan-glow/[0.10] border border-cyan-glow/30 text-white' :
                    'glass-strong'
                  }`}>{m.text}</div>
                  {m.draft && (
                    <div className="flex gap-2 mt-2 justify-start">
                      <Btn tone="primary" icon={<Icon.Send/>}>Send</Btn>
                      <Btn icon={<Icon.Spark2/>}>Regenerate</Btn>
                      <Btn icon={<Icon.X/>}>Discard</Btn>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Composer */}
          <div className="mt-4 glass-strong rounded-[14px] p-3 border-white/[0.08]">
            <div className="flex items-center gap-2 mb-2 font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/45">
              <LiveDot tone="cyan"/> scribe is composing
              <span className="text-cyan-glow tabular">{liveTokens.toFixed(0)} tok</span>
              <span className="text-white/30">·</span>
              <span className="text-white/55">approves before send</span>
            </div>
            <textarea value={draft} onChange={(e) => setDraft(e.target.value)} rows={3}
              className="w-full text-[14px] resize-none placeholder:text-white/30"
              placeholder="Type or let the assistant draft…" />
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center gap-2"><Pill tone="cyan">/draft</Pill><Pill>/summarize</Pill><Pill>/schedule</Pill></div>
              <div className="flex items-center gap-2"><Btn icon={<Icon.Spark2/>}>Refine</Btn><Btn tone="primary" icon={<Icon.Send/>}>Send via @hamdix_bot</Btn></div>
            </div>
          </div>
        </Card>

        {/* Thread context */}
        <div className="col-span-12 lg:col-span-3 space-y-5">
          <Card eyebrow="WEBHOOK" title="Bridge health">
            <div className="space-y-2 font-mono text-[12px]">
              <div className="flex justify-between"><span className="text-white/55">endpoint</span><span className="text-cyan-glow">api.hamdix.dev/tg</span></div>
              <div className="flex justify-between"><span className="text-white/55">latency</span><span className="tabular">182ms</span></div>
              <div className="flex justify-between"><span className="text-white/55">drops 24h</span><span className="tabular">0</span></div>
              <div className="flex justify-between"><span className="text-white/55">queue depth</span><span className="tabular">3</span></div>
            </div>
            <div className="mt-3"><AreaChart data={sigs} h={70} color="#5EE7A8" color2="#5EE7A8"/></div>
          </Card>

          <Card eyebrow="CONTEXT" title="Memory used">
            <div className="space-y-2.5">
              {[["ai-os", 12], ["sam", 8], ["worker-pool", 5], ["#412", 3]].map((m, i) => (
                <div key={i} className="flex items-center gap-2 text-[12.5px]">
                  <span className="w-2 h-2 rounded-full bg-cyan-glow" style={{ boxShadow: "0 0 6px #5BD4FF" }}/>
                  <span className="flex-1 text-white/82">{m[0]}</span>
                  <span className="font-mono text-[11px] text-white/45">{m[1]} refs</span>
                </div>
              ))}
            </div>
          </Card>

          <Card eyebrow="POLICY" title="Trust mode">
            <div className="space-y-2 text-[12.5px]">
              {[["read all chats", true], ["draft replies", true], ["auto-send to bots", true], ["auto-send to people", false]].map((p, i) => (
                <div key={i} className="flex items-center justify-between">
                  <span className="text-white/82">{p[0]}</span>
                  <span className={`relative inline-block w-8 h-[18px] rounded-full ${p[1] ? 'bg-cyan-glow' : 'bg-white/[0.07]'}`}>
                    <span className={`absolute top-[2px] w-[14px] h-[14px] rounded-full bg-[#06080D] transition ${p[1] ? 'left-[16px]' : 'left-[2px]'}`}/>
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* =========================================================
   SCREEN 5 — QUEUE + JOBS MONITOR
   ========================================================= */
function QueueMonitor() {
  const queues = [
    { name: "default",      depth: 18, throughput: 142, latency: 84,  workers: 8,  tone: "cyan" },
    { name: "embeddings",   depth: 5,  throughput: 22,  latency: 410, workers: 4,  tone: "azure" },
    { name: "telegram",     depth: 0,  throughput: 14,  latency: 92,  workers: 2,  tone: "pos" },
    { name: "memory.merge", depth: 2,  throughput: 1,   latency: 2200,workers: 1,  tone: "warn" },
    { name: "deploy",       depth: 0,  throughput: 0,   latency: 0,   workers: 1,  tone: "pos" },
    { name: "cron · daily", depth: 0,  throughput: 0,   latency: 0,   workers: 1,  tone: "pos" },
  ];
  const jobs = [
    { id: "01HXGT…JR8", q: "embeddings",   job: "EmbedMessages([142])",     dur: 412, status: "running",  tone: "cyan" },
    { id: "01HXGT…JK2", q: "default",      job: "ConductorRun({/daily})",   dur: 1820,status: "running",  tone: "cyan" },
    { id: "01HXGT…HP9", q: "telegram",     job: "DispatchReply(@halim)",    dur: 92,  status: "queued",   tone: "azure" },
    { id: "01HXGT…HC1", q: "memory.merge", job: "MergeSubgraph(q3-plan)",   dur: 2210,status: "running",  tone: "warn" },
    { id: "01HXGT…G4F", q: "default",      job: "ScribeCompose(brief)",     dur: 612, status: "done",     tone: "pos" },
    { id: "01HXGT…G2A", q: "default",      job: "LedgerReconcile",          dur: 88,  status: "done",     tone: "pos" },
    { id: "01HXGT…F12", q: "deploy",       job: "ShipwrightDeploy(api)",    dur: 8120,status: "done",     tone: "pos" },
    { id: "01HXGS…ZZ4", q: "default",      job: "ScoutIndex(github)",       dur: 412, status: "failed",   tone: "danger" },
    { id: "01HXGS…ZZ1", q: "embeddings",   job: "EmbedMessages([88])",      dur: 318, status: "done",     tone: "pos" },
  ];
  const max = Math.max(...queues.map(q => q.throughput));
  const histogram = useMemo(() => Array.from({length: 32}, (_, i) => 30 + Math.abs(Math.sin(i*0.6) * 60) + Math.random() * 12), []);

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="04 · RUNTIME"
        title="Queue & jobs"
        sub="Horizon-style supervision with pulse charts. Where the laravel jobs run, retry, and retire."
        right={
          <div className="flex items-center gap-2">
            <Pill tone="pos"><LiveDot/> 16 WORKERS</Pill>
            <Btn icon={<Icon.Pause/>}>Drain</Btn>
            <Btn tone="primary" icon={<Icon.Plus/>}>Scale up</Btn>
          </div>
        }
      />

      <div className="grid grid-cols-4 gap-5">
        <StatTile label="QUEUED · NOW" value={<AnimatedNumber value={25}/>} sub="across 6 queues" tone="cyan" spark={genWalk(28, 0.5, 5)}/>
        <StatTile label="THROUGHPUT · /MIN" value={<AnimatedNumber value={179}/>} sub="last 5m" tone="azure" spark={genWalk(28, 0.6, 7)}/>
        <StatTile label="P99 LATENCY" value="2.21s" sub="memory.merge" tone="warn" spark={genWalk(28, 0.7, 9)}/>
        <StatTile label="FAILED · 24H" value={<AnimatedNumber value={3}/>} sub="auto-retried" tone="pos" spark={genWalk(28, 0.4, 4)}/>
      </div>

      <div className="grid grid-cols-12 gap-5">
        {/* Queues */}
        <Card className="col-span-12 lg:col-span-5" eyebrow="QUEUES" title="Throughput by queue" right={<Pill tone="cyan"><LiveDot tone="cyan"/> 1s tick</Pill>}>
          <div className="space-y-2.5">
            {queues.map((q, i) => (
              <div key={i} className="reveal" style={{ animationDelay: `${i * 80}ms` }}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <LiveDot tone={q.tone}/>
                    <div className="text-[13px] font-mono">{q.name}</div>
                  </div>
                  <div className="font-mono text-[11px] text-white/55">depth {q.depth} · {q.workers}w · p99 {q.latency}ms</div>
                </div>
                <BarRow label="" value={q.throughput || 1} max={max} tone={q.tone} right={`${q.throughput}/min`}/>
              </div>
            ))}
          </div>
        </Card>

        {/* Histogram */}
        <Card className="col-span-12 lg:col-span-7" eyebrow="PULSE" title="Job pulse · last 8 minutes" right={<div className="flex gap-2"><Pill tone="cyan">cyan = enqueue</Pill><Pill tone="pos">green = drain</Pill></div>}>
          <div className="h-[200px] flex items-end gap-[3px]">
            {histogram.map((v, i) => (
              <div key={i} className="flex-1 relative">
                <div className="absolute bottom-0 left-0 right-0 rounded-sm" style={{
                  height: `${v}%`,
                  background: i % 4 === 3 ? "linear-gradient(180deg, #5EE7A8, #5EE7A833)" : "linear-gradient(180deg, #5BD4FF, #5BD4FF33)",
                  boxShadow: i % 4 === 3 ? "0 0 12px -2px #5EE7A8" : "0 0 12px -2px #5BD4FF",
                  opacity: 0.85,
                }}/>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-4 gap-3 mt-4 font-mono text-[11px]">
            <div><div className="text-white/45">enqueue / min</div><div className="text-cyan-glow tabular">142</div></div>
            <div><div className="text-white/45">drain / min</div><div className="text-[#5EE7A8] tabular">139</div></div>
            <div><div className="text-white/45">retry / min</div><div className="text-[#FFC56B] tabular">2</div></div>
            <div><div className="text-white/45">net depth Δ</div><div className="text-white tabular">+3</div></div>
          </div>
        </Card>

        {/* Jobs table */}
        <Card className="col-span-12" eyebrow="JOBS · 9 OF 312" title="Live executions" right={<div className="flex gap-2"><Pill>all</Pill><Pill tone="cyan">running</Pill><Pill tone="warn">retrying</Pill><Pill tone="danger">failed</Pill></div>}>
          <div className="grid grid-cols-[140px_1fr_120px_100px_120px_60px] gap-3 px-3 py-2 font-mono text-[10.5px] uppercase tracking-[0.14em] text-white/40 border-b border-white/[0.05]">
            <div>id</div><div>job</div><div>queue</div><div className="text-right">dur</div><div>status</div><div></div>
          </div>
          {jobs.map((j, i) => (
            <div key={i} className="grid grid-cols-[140px_1fr_120px_100px_120px_60px] gap-3 px-3 py-2.5 items-center border-b border-white/[0.04] last:border-0 hover:bg-white/[0.025] reveal" style={{ animationDelay: `${i * 50}ms` }}>
              <div className="font-mono text-[11.5px] text-white/55">{j.id}</div>
              <div className="text-[13px]">{j.job}</div>
              <div className="font-mono text-[11.5px] text-white/70">{j.q}</div>
              <div className="font-mono text-[12px] text-right tabular">{j.dur}<span className="text-white/40">ms</span></div>
              <div><Pill tone={j.tone}>{j.status === "running" && <LiveDot tone={j.tone}/>}{j.status}</Pill></div>
              <div className="text-right"><button className="text-white/45 hover:text-cyan-glow"><Icon.Arrow/></button></div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

/* =========================================================
   SCREEN 6 — COST ANALYTICS
   ========================================================= */
function CostAnalytics() {
  const today = useMemo(() => genWalk(60, 0.5, 5).map(v => v * 0.04), []);
  const breakdown = [
    { name: "claude · sonnet-4.5",   cost: 8.42, pct: 51, tone: "cyan" },
    { name: "claude · haiku-4.5",    cost: 3.18, pct: 19, tone: "azure" },
    { name: "openai · embed-3-large",cost: 2.10, pct: 12, tone: "aurora" },
    { name: "groq · llama-70b",      cost: 1.40, pct: 9,  tone: "warn" },
    { name: "deepgram · stt",        cost: 0.92, pct: 5,  tone: "pos" },
    { name: "elevenlabs · tts",      cost: 0.42, pct: 4,  tone: "danger" },
  ];
  const totalToday = breakdown.reduce((s, b) => s + b.cost, 0);
  const max = Math.max(...breakdown.map(b => b.cost));

  const heatmap = useMemo(() => {
    const rows = ["concierge","scout","scribe","ledger","atlas","wren","north"];
    return rows.map(r => ({ name: r, hours: Array.from({length: 24}, () => Math.random()) }));
  }, []);

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="05 · LEDGER"
        title="Cost analytics"
        sub="Every token has a name. Track spend per agent, per model, per intent — and project tomorrow before it arrives."
        right={
          <div className="flex items-center gap-2">
            <div className="glass-strong rounded-[10px] flex items-center h-9 overflow-hidden">
              {["24h","7d","30d","ytd"].map((p, i) => (
                <button key={p} className={`px-3 h-full text-[12px] font-mono uppercase tracking-[0.14em] ${i===1 ? 'bg-white/[0.08] text-cyan-glow' : 'text-white/55 hover:text-white'}`}>{p}</button>
              ))}
            </div>
            <Btn icon={<Icon.Coin/>}>Set budget</Btn>
          </div>
        }
      />

      <div className="grid grid-cols-12 gap-5">
        <div className="col-span-12 lg:col-span-8 space-y-5">
          <div className="glass p-6 ring-aurora underglow-cyan">
            <div className="flex items-end justify-between mb-3">
              <div>
                <div className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/45">today · all sources</div>
                <div className="text-[44px] tracking-[-0.02em] font-medium tabular">
                  $<AnimatedNumber value={totalToday} decimals={2}/>
                  <span className="text-[16px] text-white/40 ml-2 font-normal">/ $25.00 budget</span>
                </div>
                <div className="text-[12.5px] text-white/55 mt-1">Projected EOD <span className="text-cyan-glow tabular">$22.40</span> · 90% confident</div>
              </div>
              <div className="text-right">
                <div className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-white/45">7d run-rate</div>
                <div className="text-[18px] tabular">$1.84<span className="text-white/45">/hr</span></div>
                <div className="font-mono text-[10.5px] text-[#5EE7A8] mt-1">▾ 12% vs last week</div>
              </div>
            </div>
            <AreaChart data={today} h={180}/>
          </div>

          <Card eyebrow="HEATMAP" title="Spend per agent · 24h" right={<Pill tone="cyan">brighter = costlier</Pill>}>
            <div className="space-y-1.5">
              {heatmap.map((row, ri) => (
                <div key={ri} className="grid grid-cols-[100px_1fr] gap-3 items-center">
                  <div className="font-mono text-[11.5px] text-white/70">{row.name}</div>
                  <div className="grid grid-cols-24 gap-[2px]" style={{ gridTemplateColumns: "repeat(24,1fr)" }}>
                    {row.hours.map((h, hi) => (
                      <div key={hi} className="h-5 rounded-sm" style={{
                        background: `rgba(91,212,255,${0.06 + h * 0.6})`,
                        boxShadow: h > 0.7 ? `0 0 6px rgba(91,212,255,${h * 0.6})` : 'none',
                      }} title={`${row.name} · h${hi} · $${(h*0.6).toFixed(2)}`}/>
                    ))}
                  </div>
                </div>
              ))}
              <div className="grid grid-cols-[100px_1fr] gap-3 mt-2">
                <div></div>
                <div className="grid font-mono text-[10px] text-white/35" style={{ gridTemplateColumns: "repeat(24,1fr)" }}>
                  {Array.from({length: 24}).map((_, i) => <div key={i} className="text-center">{i % 3 === 0 ? i : ""}</div>)}
                </div>
              </div>
            </div>
          </Card>
        </div>

        <div className="col-span-12 lg:col-span-4 space-y-5">
          <Card eyebrow="BREAKDOWN" title="By model · today">
            <div className="space-y-2.5">
              {breakdown.map((b, i) => (
                <div key={i}>
                  <div className="flex items-center justify-between mb-1">
                    <div className="text-[12.5px] text-white/85">{b.name}</div>
                    <div className="font-mono text-[12px] tabular">{fmt.dollar(b.cost)}</div>
                  </div>
                  <BarRow label="" value={b.cost} max={max} tone={b.tone} right={`${b.pct}%`}/>
                </div>
              ))}
            </div>
          </Card>

          <Card eyebrow="GUARDRAILS" title="Budget rules">
            <div className="space-y-3">
              {[
                ["daily ceiling", "$25.00", "57% used", "cyan"],
                ["per-task max", "$1.50", "no breach", "pos"],
                ["scribe.compose", "$0.40 ea", "1 breach", "warn"],
                ["pause if eod >", "$22.00", "armed", "azure"],
              ].map((r, i) => (
                <div key={i} className="flex items-center justify-between glass-strong rounded-[10px] px-3 py-2.5">
                  <div>
                    <div className="text-[12.5px] text-white/85">{r[0]}</div>
                    <div className="font-mono text-[10.5px] text-white/45 mt-0.5">{r[2]}</div>
                  </div>
                  <Pill tone={r[3]}>{r[1]}</Pill>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

window.TelegramConsole = TelegramConsole;
window.QueueMonitor = QueueMonitor;
window.CostAnalytics = CostAnalytics;
